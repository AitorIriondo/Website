$(function() {


			var piechartSettings = {
				series: {
					pie: {show: true,
						},
				legend: {
					show: false
				},
			 }
			};


		var data_aitor = [
			{data: 7, color:"rgb(255, 0, 0)",},
			{data: 3, color:"rgb(255, 255, 0)",},
			{data: 9, color:"rgb(0, 255, 0)",},
			{data: 0, color:"rgb(139,0,139)",},
		];
		
		var data_nafise = [
			{data: 1, color:"rgb(255, 0, 0)",},
			{data: 6, color:"rgb(255, 255, 0)",},
			{data: 8, color:"rgb(0, 255, 0)",},
			{data: 1, color:"rgb(139,0,139)",},
		];
		
		var data_pam = [
			{data: 5, color:"rgb(255, 0, 0)",},
			{data: 1, color:"rgb(255, 255, 0)",},
			{data: 1, color:"rgb(0, 255, 0)",},
			{data: 0, color:"rgb(139,0,139)",},

		];
		
		var data_dan = [
			{data: 6, color:"rgb(255, 0, 0)",},
			{data: 6, color:"rgb(255, 255, 0)",},
			{data: 6, color:"rgb(0, 255, 0)",},
			{data: 3, color:"rgb(139,0,139)",},
		];
		
		var data_user = [
			{data: 1, color:"rgb(255, 0, 0)",},
			{data: 7, color:"rgb(255, 255, 0)",},
			{data: 3, color:"rgb(0, 255, 0)",},
			{data: 0, color:"rgb(139,0,139)",},
		];
		
		
		$.plot($("#piechart_aitor"), data_aitor, piechartSettings);
		$.plot($("#piechart_nafise"), data_nafise, piechartSettings);  		
		$.plot($("#piechart_pam"), data_pam, piechartSettings);
		$.plot($("#piechart_dan"), data_dan, piechartSettings);
		$.plot($("#piechart_user"), data_user, piechartSettings);

});