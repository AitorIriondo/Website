     <form action="upload.php" method="post" enctype="multipart/form-data">
            Select CSV file to upload
            <input type="file" name="fileToUpload" accept=".csv">
            <input type="submit" value="Upload File" name="submit">
        </form>

