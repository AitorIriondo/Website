<html>
<link rel="stylesheet" type="text/css" href="container.css">
<link rel="stylesheet" type="text/css" href="font.css">
<link rel="stylesheet" type="text/css" href="background.css">
<img src="IPS.png" alt="Industrial Path Solutions"style="width:120px;height:45px;">
<div class="style">
<h1><center>IMMA web evaluator</center></h1>
</div>	
<div class="container"> <span>
	<p>
		<center>
			<form action="user_interface.php" method="get">
				Username <br/>
				<input name="user" type="text"><br/>
				<br/>
				Password <br/>
				<input password="password" type="password"><br/>
				<br/>
				<input type="submit" value="Log in">
			</form>

	</p>
</span>
</div>

</body>
</html>